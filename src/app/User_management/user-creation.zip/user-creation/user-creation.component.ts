



import { NoopScrollStrategy } from '@angular/cdk/overlay';
import { Component, ElementRef, HostListener, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { first } from 'rxjs/operators';
import { AlertService } from 'src/app/_services/alert.service';
// import { CustomerService } from 'src/app/_services/customer.service';
// import { UserService } from 'src/app/_services/user.service';
import { AccountService } from '../../_services/account.service';
import { UserAddFieldComponent } from '../user-add-field/user-add-field.component';


@Component({
  selector: 'app-user-creation',
  templateUrl: './user-creation.component.html',
  styleUrls: ['./user-creation.component.css'],
  encapsulation: ViewEncapsulation.None,
  styles: [`
     .modal-content {
      background-color: white;
      color: black;
      margin-top:40%;
      border-radius:13px;
    }
    `]
})
export class UserCreationComponent implements OnInit {
  @ViewChild('exampleModal', { static: true }) exampleModalRef: ElementRef;
  @ViewChild('closeButton') closeButton;
  public buttonName: any = 'Show';
  public sys: boolean = false;
  public contact: boolean = false;
  loading = false;
  form: FormGroup;
  submitted = false;


  products7;
  products8 = [];
  products9 = [];
  products10 = [];
  products11 = [];
  usergrp = [];
  role = [];
  designation = [];
  department = [];
  floor = [];
  usertype = [];
  reportingtoo = [];
  userType1: any;
  empid1: any;

  keyword1='username1';
  empid2: any;


  div1: boolean = true;
  div2: boolean = true;
  div3: boolean = true;
  statusClass = 'not-active';
  statusClasses = 'not-active';
  statusClassess = 'not-active';
  orga: any;


  setActiveClass1() {
    this.statusClass = "active";
    this.statusClasses = "not-active";
    this.statusClassess = "not-active";

  }

  setActiveClass2() {
    this.statusClasses = "active";
    this.statusClass = "not-active";
    this.statusClassess = "not-active";

  }
  setActiveClass3() {
    this.statusClass = "not-active";
    this.statusClasses = "not-active";
    this.statusClassess = "active";
  }
  formSubmit(val: any) {
    console.log(val)
  }




  constructor(
    public accountservice: AccountService,public dialog: MatDialog,
  
    private formBuilder: FormBuilder, public alterservices: AlertService, 
     private router: Router,  private modalService:NgbModal ) { }

    // @HostListener('window:keyup.esc') onKeyUp() {
    // }

  ngOnInit(): void {
   
    this.dropdown();

    this.form = this.formBuilder.group({
      role: ['', Validators.required],
     // usergrp: ['', Validators.required],
      designation: ['', Validators.required],
      building: ['', Validators.required],
      floor: ['', Validators.required],
      org: ['', Validators.required],
      branch: ['', Validators.required],
      firstname: ['', Validators.required],
      middlename: ['', Validators.required],
      lastname: ['', Validators.required],
      title: ['', Validators.required],
      email: ['', Validators.required],
      eightid: ['', Validators.required],
      scode: ['', Validators.required],
      loginname: [''],
      empid: ['', Validators.required],
      usertype: ['', Validators.required],
      reportingto : ['', Validators.required],
      department: ['', Validators.required],
      password: [''],
      vipstatus: ['', Validators.required],
      description: [''],
      landline:[''],
      mobile:[''],
      deskno:[''],
      repempid:[''],
      actionid:[this.accountservice.user.userid],
      supgrp:['']


      
    });
    setTimeout(() => {      
      this.form.patchValue({
        // org:this.accountService.user.orgname
      });
    }, 1000);
  

}

openVerticallyCentered(content:any) {
  this.modalService.open(content, { centered: true });


}

close(){
       this.router.navigate(['/home/users/userlist']);
}

openVertically(content1:any) {
  this.modalService.open(content1, { centered: true });
}

closed()
{
  setTimeout(function () { location.href='/home/users/userlist'; }, 3000);
  // this.router.navigate(['/userc']);
}



get f() { return this.form.controls; }


isCancel = false
cancelDisplay() {
  this.router.navigate(['/home/users/userlist']);
  this.isCancel = !this.isCancel;

}




OnlyNumbersAllowed(event):boolean
{
const charCode = (event.which)?event.which:event.keyCode;
if(charCode > 31 && (charCode <48 || charCode > 57))
{
  console.log('charCode restricted is '+ charCode);
  return false;
}
return true;
}



// get f() { return this.form.controls; }

toggle() {
  this.sys = !this.sys;

  // CHANGE THE NAME OF THE BUTTON.
  if (this.sys)
    this.buttonName = "Hide";
  else
    this.buttonName = "Show";

}
toggle1() {
  this.contact = !this.contact;

  // CHANGE THE NAME OF THE BUTTON.
  if (this.contact)
    this.buttonName = "Hide";
  else
    this.buttonName = "Show";

}
dropdown() {
  this.accountservice.title().subscribe(data => {
    this.products7 = data.rows;
  }),
    this.accountservice.organization().subscribe(data => {
      this.products8 = data.rows;
    }),

    this.accountservice.building().subscribe(data => {
      this.products9 = data.rows;
    }),
    this.accountservice.branch().subscribe(data => {
      this.products10 = data.rows;
    }),
    this.accountservice.sectioncode().subscribe(data => {
      this.products11 = data.rows;
    }),
    this.accountservice.getUserGroup().subscribe(data => {
      this.usergrp = data.rows;
    }),
    this.accountservice.getUserRole().subscribe(data => {
      this.role = data.rows;
    }),
    this.accountservice.designation().subscribe(data => {
      this.designation = data.rows;
    }),
  this.accountservice.department().subscribe(data => {
    this.department = data.rows;
  }),
  this.accountservice.usertype().subscribe(data => {
    this.usertype = data.rows;
  }),
  // this.accountservice.reportingtoo().subscribe(data => {
  //   this.reportingtoo = data.rows;
  // }),
  this.accountservice.alluserdetails1().subscribe(data => {
    this.reportingtoo = data.rows;
    console.log(this.reportingtoo)
  });

}

getFloor(building){

  this.accountservice.floor(building)
      .subscribe(floor => {
          this.floor = floor.rows;
      });
}

// onNoClick() {
//   this.dialogRef.close();
// }

onSubmit() {
 debugger;
 this.form.value.firstname = this.form.value.firstname.trim();
 this.form.value.lastname = this.form.value.lastname.trim();
 this.form.value.middlename = this.form.value.middlename.trim();

  this.submitted = true;

  // reset alerts on submit
  this.alterservices.clear();

  this.empid1 = this.empid2.split('/');
  this.form.value.reportingto = this.empid1[0];
  this.form.value.repempid = this.empid1[1];
  console.log(this.form.value);

  // stop here if form is invalid
  if (this.form.invalid) {
    //this.form.value.reportingto = this.empid1[0]+'/'+ this.empid1[1];
    return;
  }

  this.loading = true;
  this.createUser();

}

createUser() {
  console.log(this.form);

  this.accountservice.newUser(this.form.value)
    .subscribe(res => {
     
      console.log(res);
      this.loading = false;
     if(res.Status === 'User created Successfully'){
    
     //  this.onNoClick();
       this.alterservices.success('User Created successfully', {autoClose:true, keepAfterRouteChange: true });
      
     }else if(res.message){
      this.alterservices.success(res.message, {autoClose:true, keepAfterRouteChange: true });
      
     }
   else if(res.error){
      this.alterservices.error(res.error, {autoClose:true, keepAfterRouteChange: true });
     
     }
    
    
    },
      error => {
        this.loading = false;
        this.alterservices.error(error);
       
      }
    );
  
    

}


addField(item){

  const dialogRef = this.dialog.open(UserAddFieldComponent, {
    width: 'auto',
    scrollStrategy: new NoopScrollStrategy(),
    disableClose:true,
    data : {data:item}
  });

  dialogRef.afterClosed().subscribe(result => {
    if(item === 'Designation'){
      this.accountservice.designation().subscribe(data => {
        this.designation = data.rows;
      })
    }else if(item === 'department'){
      this.accountservice.department().subscribe(data => {
        this.department = data.rows;
      })
    }
    else if(item === 'Section Code'){
      this.accountservice.sectioncode().subscribe(data => {
        this.products11 = data.rows;
      })
    }
    else if(item === 'Branch'){
      this.accountservice.branch().subscribe(data => {
        this.products10 = data.rows;
      })
    }
    else if(item === 'Building'){
      this.accountservice.building().subscribe(data => {
        this.products9 = data.rows;
      })
    }
   


  
    console.log('The dialog was closed');
  });


}

osystem(item){
  // this.osys = os;
  if(item === 'ADD NEW Department' ){
    document.getElementById('exampleModal1').click();
  }
  else if(item === 'ADD NEW Designation'){
    document.getElementById('exampleModal2').click();
  }
  else if(item === 'ADD NEW Building'){
    document.getElementById('exampleModal3').click();
  }
  else if(item === 'ADD NEW Section Code'){
    document.getElementById('exampleModal4').click();
  }
  else if(item === 'ADD NEW Floor'){
    document.getElementById('exampleModal5').click();
  }
  else if(item === 'ADD NEW Branch'){
    document.getElementById('exampleModal6').click();
  }
 
 
  console.log(item);
}


selectEvent(item) {
   this.empid2 = item.username1
   
  // do something with selected item
}

onChangeSearch(val: string) {
  // fetch remote data from here
  // And reassign the 'data' which is binded to 'data' property.
}

onFocused(e){
  // do something when input is focused
}



@HostListener('window:scroll', ['$event'])
onScroll(e) {
 // console.log('window', e);
}

 

divScroll(e) {
  console.log('div App', e);
}



}


